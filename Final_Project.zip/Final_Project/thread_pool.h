/*
	Nathan Bolles
	nabolles@mix.wvu.edu
	800107004
	Dillon Louden
	djlouden@mix.wvu.edu
	800100244
	CS 350 Final Project
*/

#ifndef Final_Assignment_THREAD_POOL_H
#define Final_Assignment_THREAD_POOL_H

typedef enum {FALSE, TRUE} bool;

typedef struct ThreadPool{
	int number_of_workers;
  bool active;
	Job* job_pointer;
  pthread_t* thread;
  pthread_attr_t joinable;
}ThreadPool;

ThreadPool* CreateThreadPool(const int number_of_workers);

void DestroyThreadPool(ThreadPool* thread_pool);

void EnqueueJob(ThreadPool* thread_pool, Job* job);

void ExecuteJobs(ThreadPool* thread_pool);

bool IsThreadPoolActive(ThreadPool* thread_pool);

int GetNumberOfRemaningJobs(ThreadPool* thread_pool);

#endif
