/*Nathan Bolles
nabolles@mix.wvu.edu
800107004*/
/*Dillon Louden
djlouden@mix.wvu.edu
800100244*/

#ifndef Final_Assignment
#define Final_Assignment

typedef enum [FALSE, TRUE] bool;

typedef ThreadPool{
	int number_of_workers;
  	bool active;
  	Jobs* pointer;
  	pthread_t thread[];
  	void* joinable;
} ThreadPool;

ThreadPool* CreateThreadPool(const int number_of_workers);

void DestroyThreadPool(ThreadPool* thread_pool);

void EnqueueJob(ThreadPool* thread_pool, Job* job);

void ExecuteJobs(ThreadPool* thread_pool);

bool IsThreadPoolActive(ThreadPool* thread_pool);

int GetNumberOfRemaningJobs(ThreadPool* thread_pool);

#endif
