/*
  Nathan Bolles
  nabolles@mix.wvu.edu
  800107004
  Dillon Louden
  djlouden@mix.wvu.edu
  800100244
  CS 350 Final Project
*/

#include "thread_pool.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>



ThreadPool* CreateThreadPool(const int number_of_workers){

}

void DestroyThreadPool(ThreadPool* thread_pool){

}

void EnqueueJob(ThreadPool* thread_pool, Job* job){

}

void ExecuteJobs(ThreadPool* thread_pool){

}

bool IsThreadPoolActive(ThreadPool* thread_pool){

}

int GetNumberOfRemaningJobs(ThreadPool* thread_pool){

}
