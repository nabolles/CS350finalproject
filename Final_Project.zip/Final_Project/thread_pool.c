/*
  Nathan Bolles
  nabolles@mix.wvu.edu
  800107004
  Dillon Louden
  djlouden@mix.wvu.edu
  800100244
  CS 350 Final Project
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "job.h"
#include "queue.h"
#include "thread_pool.h"

ThreadPool* CreateThreadPool(const int number_of_workers){
  if(number_of_workers <= 0){
    return NULL;
  }
  ThreadPool* thread_pool = (ThreadPool*) malloc(sizeof(ThreadPool));
  thread_pool ->num_workers = number_of_workers;
  thread_pool ->active = FALSE;
  thread_pool ->workers = (pthread_t*) malloc(number_of_workers * sizeof(pthread_t));
  thread_pool ->queue = CreateQueue();
  return thread_pool;
}

void DestroyThreadPool(ThreadPool* thread_pool){
  if(!thread_pool){
    return;
  }
  DestroyQueue(thread_pool ->queue);
  free(thread_pool ->workers);
  pthread_attr_destroy(&thread_pool ->joinable);
  thread_pool ->workers = NULL;
  thread_pool ->queue = NULL;
  thread_pool ->active = FALSE;
  free(thread_pool);
}

void EnqueueJob(ThreadPool* thread_pool, Job* job){
  if(!thread_pool || !job){
    return;
  }
  Enqueue(thread_pool ->queue, job);
}

void ExecuteJobs(ThreadPool* thread_pool){
  if(!thread_pool){
    return;
  }

  thread_pool ->active = TRUE;
  pthread_attr_init(&thread_pool ->joinable);
  pthread_attr_setdetachstate(&thread_pool ->joinable, PTHREAD_CREATE_JOINABLE);
  int i;
  for(i = 0; i < thread_pool ->num_workers; ++i){
    if(pthread_create(&thread_pool ->workers[i], &thread_pool ->joinable, &activity, thread_pool)){
      printf("Failed to create a thread!\n");
      return;
    }
  }
  for(i = 0; i < thread_pool ->num_workers; ++i){
    pthread_join(thread_pool ->workers[i], NULL);
  }
}

bool IsThreadPoolActive(ThreadPool* thread_pool){
  if(!thread_pool){
    return -1;
  }
  return thread_pool ->active;
}

int GetNumberOfRemainingJobs(ThreadPool* thread_pool){
  if(!thread_pool){
    return -1;
  }
  return thread_pool ->queue ->size;
}

void* activity(void* argument){
  if(!argument){
    return NULL;
  }
  ThreadPool* thread_pool = (ThreadPool*) argument;
  Job* job;
  while(GetNumberOfRemainingJobs(thread_pool) > 0){
    job = Dequeue(thread_pool ->queue);
    if(job){
      (job ->job_description)(job ->input, job ->output);
    }
    DestroyJob(job);
  }
  pthread_exit(NULL);
}
