/*
  Nathan Bolles
  nabolles@mix.wvu.edu
  800107004
  Dillon Louden
  djlouden@mix.wvu.edu
  800100244
  CS 350 Final Project
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "job.h"
#include "queue.h"
#include "thread_pool.h"

// works up to test 4

ThreadPool* CreateThreadPool(const int number_of_workers){
  if(number_of_workers <= 0){
    return NULL;
  }
  ThreadPool* thread_pool = (ThreadPool*) malloc(sizeof(ThreadPool));
  thread_pool ->workers = number_of_workers;
  thread_pool ->active = FALSE;
  thread_pool ->job_pointer = NULL;
  thread_pool ->thread = NULL;
  thread_pool ->queue = CreateQueue();
  //thread_pool ->joinable = ;
  return thread_pool;
}

// Not working
// void DestroyThreadPool(ThreadPool* thread_pool){
//   if(!thread_pool){
//     return;
//   }
//   do{
//     free();
//   }while(thread_pool ->queue != NULL);
//   free(thread_pool);
// }

// This doesnt work
void EnqueueJob(ThreadPool* thread_pool, Job* job){
  if(!thread_pool || !job){
    return;
  }
  Enqueue(thread_pool ->queue, job);
}

void ExecuteJobs(ThreadPool* thread_pool){
  if(!thread_pool){
    return;
  }
  pthread_attr_t attributes;
  pthread_mutex_t mutex;
  pthread_attr_init(&attributes);
  pthread_attr_setdetachstate(&attributes, PTHREAD_CREATE_JOINABLE);
  pthread_mutex_init(&mutex, NULL);
  int i;
  for(i = 0; i < thread_pool ->queue ->size; ++i){
    //thread_pool ->joinable[i].thread = &thread;
    if(pthread_create(&thread_pool ->thread[i], &attributes, &CreateJob, NULL)){
      printf("Failed to create a thread!\n");
    }
    for(i = 0; i < thread_pool ->queue ->size; ++i){
      pthread_join(thread_pool ->thread[i], NULL);
    }
    pthread_attr_destroy(&attributes);
    pthread_mutex_destroy(&mutex);
  }
}

bool IsThreadPoolActive(ThreadPool* thread_pool){
  if(!thread_pool){
    return -1;
  }
  return thread_pool ->active;
}

int GetNumberOfRemainingJobs(ThreadPool* thread_pool){
  if(!thread_pool){
    return -1;
  }
  return thread_pool ->queue ->size;
}
