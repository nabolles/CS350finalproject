/*
  Nathan Bolles
  nabolles@mix.wvu.edu
  800107004
  Dillon Louden
  djlouden@mix.wvu.edu
  800100244
  CS 350 Final Project
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "job.h"
#include "thread_pool.h"

ThreadPool* CreateThreadPool(const int number_of_workers){
  if(number_of_workers <= 0){
    return NULL;
  }
  ThreadPool* thread_pool = (ThreadPool*) malloc(sizeof(ThreadPool));
  thread_pool ->number_of_workers = number_of_workers;
  thread_pool ->active = FALSE;
  thread_pool ->pointer = NULL;
}

void DestroyThreadPool(ThreadPool* thread_pool){

}

void EnqueueJob(ThreadPool* thread_pool, Job* job){

}

void ExecuteJobs(ThreadPool* thread_pool){

}

bool IsThreadPoolActive(ThreadPool* thread_pool){

}

int GetNumberOfRemaningJobs(ThreadPool* thread_pool){

}
