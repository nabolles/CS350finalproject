/*
	Nathan Bolles
	nabolles@mix.wvu.edu
	800107004
	Dillon Louden
	djlouden@mix.wvu.edu
	800100244
	CS 350 Final Project
*/

#ifndef Final_Assignment_QUEUE_H
#define Final_Assignment_QUEUE_H

#include <pthread.h>

typedef struct Queue{
	Job* first;
	int size;
	pthread_mutex_t mutex;
}Queue;

Queue* CreateQueue();

void DestroyQueue(Queue* queue);

void Enqueue(Queue* queue, Job* inserted_job);

Job* Dequeue(Queue* queue);

int GetQueueSize(Queue* queue);

#endif
