/*Nathan Bolles
nabolles@mix.wvu.edu
800107004*/
/*Dillon Louden
djlouden@mix.wvu.edu
800100244*/

#ifndef QUEUE_H_
#define QUEUE_H_

typedef struct Queue{
	Job* first;
	int size;
} queue;

Queue* CreateQueue();

void DestroyQueue(Queue* destroy);

void Enqueue(Queue* queue, Job* insert);

int getQueueSize(Queue* queue);

#endif
