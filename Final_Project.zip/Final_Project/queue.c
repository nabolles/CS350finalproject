/*
  Nathan Bolles
  nabolles@mix.wvu.edu
  800107004
  Dillon Louden
  djlouden@mix.wvu.edu
  800100244
  CS 350 Final Project
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "job.h"
#include "queue.h"

Queue* CreateQueue(){
  Queue* queue = (Queue*) malloc(sizeof(Queue));
  queue ->first = NULL;
  queue ->size = 0;
  return queue;
}

void DestroyQueue(Queue* queue){
  Job* job;
  if(!queue){
    return;
  }
  do{
    free(queue ->first);
    queue ->first = job ->next;
    queue ->size--;
  }while(queue ->size != 0);
  free(queue);
}

void Enqueue(Queue* queue, Job* inserted_job){
  if(!queue || !inserted_job){
    return;
  }
  Job* temp;
  if(queue ->first == NULL){
    queue ->first = inserted_job;
  }
  else{
    temp = queue ->first;
    while(temp ->next != NULL){
      temp = temp ->next;
    }
    temp ->next = inserted_job;
  }
  queue ->size++;
  inserted_job ->next = NULL;
}

Job* Dequeue(Queue* queue){
  if(!queue || queue ->size == 0){
    return NULL;
  }
  Job* job = queue ->first;
  queue ->first = job ->next;
  queue ->size--;
  return job;
}

int GetQueueSize(Queue* queue){
  if(!queue){
    return -1;
  }
  return queue ->size;
}
