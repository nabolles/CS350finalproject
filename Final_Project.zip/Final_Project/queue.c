/*
  Nathan Bolles
  nabolles@mix.wvu.edu
  800107004
  Dillon Louden
  djlouden@mix.wvu.edu
  800100244
  CS 350 Final Project
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "job.h"
#include "queue.h"

/*
  Passesd: Test 1, Test 2, Test 4, Test 5, Test 6, Test 7
  Failed: Test 3 ([ERROR] Wrong retrieval of job: 0. Returned job 127
                  Segmentation fault: 11)
*/

Queue* CreateQueue(){
  Queue* queue = (Queue*) malloc(sizeof(Queue));
  queue ->first = NULL;
  queue ->size = 0;
  return queue;
}

void DestroyQueue(Queue* queue){
  Job* job;
  if(!queue){
    return;
  }
  do{
    free(queue ->first);
    queue ->first = job ->next;
    queue ->size--;
  }while(queue ->size != 0);
  free(queue);
}

void Enqueue(Queue* queue, Job* inserted_job){
  if(!queue || !inserted_job){
    return;
  }
  queue ->first = inserted_job;
  queue ->size++;
}

// the only one that doesnt work. Test 3
Job* Dequeue(Queue* queue){
  if(!queue || queue ->size == 0){
    return NULL;
  }
  Job* job = queue ->first;
  queue ->first = job ->next;
  queue ->size--;
  return job;
}

int GetQueueSize(Queue* queue){
  if(!queue){
    return -1;
  }
  return queue ->size;
}
