/*Nathan Bolles
nabolles@mix.wvu.edu
800107004*/
/*Dillon Louden
djlouden@mix.wvu.edu
800100244*/

#include "queue.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


Queue* CreateQueue(){


}

void DestroyQueue(Queue* destroy){


}

void Enqueue(Queue* queue, Job* insert){


}

int getQueueSize(Queue* queue){


}
